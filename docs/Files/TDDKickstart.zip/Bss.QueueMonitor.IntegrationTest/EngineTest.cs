﻿using Bss.QueueMonitor;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Bss.Logging;
using Bss.ReliableMessaging;
using Bss.QueueMonitor.Data;
using Bss.Timing;
using System.Messaging;
using Bss.UnitTesting;

namespace Bss.QueueMonitor.IntegrationTest
{
    [TestClass()]
    public class EngineTest
    {
        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        string _sourceQueueName = string.Empty;

        [TestMethod()]
        public void MonitorQueueDepthShouldMonitorTheQueueAndStoreItsDepthValuesInTheDatabase()
        {
            ILoggingProvider loggingProvider = new Bss.Logging.TestContext.Provider(this.TestContext);
            IReliableMessagingProvider reliableMessagingProvider = new Bss.ReliableMessaging.Msmq.Provider(loggingProvider);
            IQueueDepthRepository repository = new Bss.QueueMonitor.Data.EF.QueueDepthRepository();
            ITimingProvider timingProvider = new Bss.Timing.Provider();

            _sourceQueueName = GetRandomQueueName();
            CreateQueue(_sourceQueueName, false);

            int executionCount = 7.GetRandom(2);

            try
            {
                InsertRandomMessages(_sourceQueueName);
                InsertRandomMessages(_sourceQueueName);

                TimeSpan delayBetweenExecutions = TimeSpan.FromMilliseconds(2000.GetRandom());
                var target = new Queue(_sourceQueueName, loggingProvider, reliableMessagingProvider, repository, timingProvider);
                target.Monitor(executionCount, delayBetweenExecutions);
            }
            finally
            {
                PurgeQueue(_sourceQueueName);
                DeleteQueue(_sourceQueueName);
            }
        }

        #region Helper Methods

        void InsertRandomMessages(string queueName)
        {
            int n = 5.GetRandom();
            for (int i = 0; i < n; i++)
            {
                string message = string.Empty.GetRandom();
                SendMessage(queueName, message);
            }
        }

        string GetRandomQueueName()
        {
            return string.Format(@".\private$\{0}", Guid.NewGuid().ToString()).Replace("-",string.Empty);
        }

        void CreateQueue(string queueName, bool transactional)
        {
            System.Messaging.MessageQueue.Create(queueName, transactional);
        }

        void DeleteQueue(string queueName)
        {
            System.Messaging.MessageQueue.Delete(queueName);
        }

        void SendMessage(string queueName, string message)
        {
            using (System.Messaging.MessageQueue messageQueue = new System.Messaging.MessageQueue(queueName, System.Messaging.QueueAccessMode.Send))
            {
                messageQueue.Formatter = new System.Messaging.XmlMessageFormatter();

                if (messageQueue.Transactional)
                {
                    using (System.Messaging.MessageQueueTransaction trans = new System.Messaging.MessageQueueTransaction())
                    {
                        trans.Begin();
                        messageQueue.Send(message, trans);
                        trans.Commit();
                    }
                }
                else
                    messageQueue.Send(message);

                messageQueue.Close();
            }
        }

        private static string ReceiveMessage(string queueName)
        {
            System.Messaging.Message message;

            using (System.Messaging.MessageQueue messageQueue = new System.Messaging.MessageQueue(queueName, System.Messaging.QueueAccessMode.Receive))
            {
                string[] targetTypeNames = new string[] { "System.String" };
                messageQueue.Formatter = new System.Messaging.XmlMessageFormatter(targetTypeNames);

                try
                {
                    if (messageQueue.Transactional)
                    {
                        using (System.Messaging.MessageQueueTransaction trans = new System.Messaging.MessageQueueTransaction())
                        {
                            trans.Begin();
                            message = messageQueue.Receive(new TimeSpan(0), trans);
                            trans.Commit();
                        }
                    }
                    else
                        message = messageQueue.Receive(new TimeSpan(0));
                }
                catch (System.Messaging.MessageQueueException)
                {
                    throw new QueueEmptyException(queueName);
                }
            }

            return message.Body.ToString();
        }

        private void PurgeQueue(string queueName)
        {
            bool done = false;
            while (!done)
            {
                try
                {
                    ReceiveMessage(queueName);
                }
                catch (QueueEmptyException)
                {
                    done = true;
                }
            }
        }

        #endregion

    }
}

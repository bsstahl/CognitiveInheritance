﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bss.ReliableMessaging
{
    public interface IReliableMessagingTransaction:IDisposable
    {
        Guid Id { get; }
        bool Active { get; }
        System.Collections.Generic.Dictionary<string, object> PropertyBag { get; }

        void Commit();
        void Rollback();

    }
}

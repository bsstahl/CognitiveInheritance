﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bss.ReliableMessaging
{
    public interface IReliableMessagingProvider:IDisposable
    {
        bool IsTransactable(string queue);

        void PutMessageOnQueue(string queue, string message);
        void PutMessageOnQueue(IReliableMessagingTransaction transaction, string message);

        string GetMessageFromQueue(string queue);
        string GetMessageFromQueue(IReliableMessagingTransaction transaction);

        IReliableMessagingTransaction BeginReadTransaction(string queue);
        IReliableMessagingTransaction BeginWriteTransaction(string queue);

        Int64 GetQueueDepth(string queue);
    }
}

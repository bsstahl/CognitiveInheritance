﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bss.ReliableMessaging
{
    [Serializable]
    public class QueueEmptyException : ReliableMessagingException
    {
        /// <summary>
        /// The default constructor for the ReliableMessagingException
        /// </summary>
        public QueueEmptyException()
            : base()
        { }

        /// <summary>
        /// The constructor which accepts the name of the queue that is empty
        /// </summary>
        /// <param name="message">The queue name of the empty queue</param>
        public QueueEmptyException(string queueName)
            : base(string.Format(System.Globalization.CultureInfo.CurrentCulture, "Queue '{0}' is empty.", queueName))
        { }

        /// <summary>
        /// The constructor which accepts a message describing the error
        /// and an exception which is the trapped exception caught by the provider
        /// </summary>
        /// <param name="message">A description of the error that occurred</param>
        /// <param name="innerException">The exception that was trapped by the provider</param>
        public QueueEmptyException(string message, System.Exception innerException) : base(message, innerException) { }

        protected QueueEmptyException(System.Runtime.Serialization.SerializationInfo info, System.Runtime.Serialization.StreamingContext context) : base(info, context) { }

    }
}

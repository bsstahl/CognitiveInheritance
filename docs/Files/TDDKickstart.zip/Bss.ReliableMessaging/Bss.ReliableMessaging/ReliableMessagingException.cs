﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bss.ReliableMessaging
{
    [Serializable]
    public class ReliableMessagingException:System.Exception
    {
        /// <summary>
        /// The default constructor for the ReliableMessagingException
        /// </summary>
        public ReliableMessagingException() : base() { }

        /// <summary>
        /// The constructor which accepts a message describing the error
        /// </summary>
        /// <param name="message">A description of the error that occurred</param>
        public ReliableMessagingException(string message) : base(message) { }

        /// <summary>
        /// The constructor which accepts a message describing the error
        /// and an exception which is the trapped exception caught by the provider
        /// </summary>
        /// <param name="message">A description of the error that occurred</param>
        /// <param name="innerException">The exception that was trapped by the provider</param>
        public ReliableMessagingException(string message, System.Exception innerException) : base(message, innerException) { }

        protected ReliableMessagingException(System.Runtime.Serialization.SerializationInfo info, System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Messaging;

namespace Bss.ReliableMessaging.Msmq
{
    public class Provider : Bss.ReliableMessaging.IReliableMessagingProvider
    {
        const string _eventCategory = "ReliableMessaging";
        Bss.Logging.ILoggingProvider _loggingProvider;

        public Provider(Bss.Logging.ILoggingProvider loggingProvider)
        {
            _loggingProvider = loggingProvider;
        }

        #region IReliableMessagingProvider Members

        public bool IsTransactable(string queue)
        {
            bool result;
            using (System.Messaging.MessageQueue messageQueue = new System.Messaging.MessageQueue(queue, System.Messaging.QueueAccessMode.PeekAndAdmin))
            {
                result = messageQueue.Transactional;
                messageQueue.Close();
            }
            return result;
        }

        public void PutMessageOnQueue(string queue, string message)
        {
            using (System.Messaging.MessageQueue messageQueue = new System.Messaging.MessageQueue(queue, System.Messaging.QueueAccessMode.Send))
            {
                messageQueue.Formatter = new System.Messaging.XmlMessageFormatter();

                if (messageQueue.Transactional)
                {
                    using (System.Messaging.MessageQueueTransaction trans = new System.Messaging.MessageQueueTransaction())
                    {
                        trans.Begin();
                        messageQueue.Send(message, trans);
                        trans.Commit();
                    }
                }
                else
                    messageQueue.Send(message);

                messageQueue.Close();
            }
        }

        public void PutMessageOnQueue(Bss.ReliableMessaging.IReliableMessagingTransaction transaction, string message)
        {
            if (!transaction.Active)
            {
                string errorMessage = string.Format("Unable to enqueue message using transaction '{0}' because the transaction is not active", transaction.Id);
                LogEvent("Inactive Transaction Error", errorMessage, 2, System.Diagnostics.EventLogEntryType.Error);
                throw new System.InvalidOperationException(errorMessage);
            }

            System.Messaging.MessageQueue queue = GetFromPropertyBag<System.Messaging.MessageQueue>(transaction.PropertyBag, Keys.Queue); //transaction.PropertyBag[Keys.Queue] as System.Messaging.MessageQueue;
            System.Messaging.MessageQueueTransaction trans = GetFromPropertyBag<System.Messaging.MessageQueueTransaction>(transaction.PropertyBag, Keys.Transaction); // transaction.PropertyBag[Keys.Transaction] as System.Messaging.MessageQueueTransaction;
            PutMessageOnQueue(queue, trans, message);
        }

        public string GetMessageFromQueue(string queue)
        {
            System.Messaging.Message message;

            using (System.Messaging.MessageQueue messageQueue = new System.Messaging.MessageQueue(queue, System.Messaging.QueueAccessMode.Receive))
            {
                string[] targetTypeNames = new string[] { "System.String" };
                messageQueue.Formatter = new System.Messaging.XmlMessageFormatter(targetTypeNames);

                try
                {
                    if (messageQueue.Transactional)
                    {
                        using (System.Messaging.MessageQueueTransaction trans = new System.Messaging.MessageQueueTransaction())
                        {
                            trans.Begin();
                            message = messageQueue.Receive(new TimeSpan(0), trans);
                            trans.Commit();
                        }
                    }
                    else
                        message = messageQueue.Receive(new TimeSpan(0));
                }
                catch (System.Messaging.MessageQueueException)
                {
                    throw new QueueEmptyException(queue);
                }
            }

            return message.Body.ToString();
        }

        public string GetMessageFromQueue(Bss.ReliableMessaging.IReliableMessagingTransaction transaction)
        {
            System.Messaging.Message message;

            if (!transaction.Active)
            {
                string errorMessage = string.Format("Unable to dequeue message using transaction '{0}' because the transaction is not active", transaction.Id);
                LogEvent("Inactive Transaction Error", errorMessage, 2, System.Diagnostics.EventLogEntryType.Error);
                throw new System.InvalidOperationException(errorMessage);
            }

            System.Messaging.MessageQueue queue = GetFromPropertyBag<System.Messaging.MessageQueue>(transaction.PropertyBag, Keys.Queue); // transaction.PropertyBag[Keys.Queue] as System.Messaging.MessageQueue;
            string[] targetTypeNames = new string[] { "System.String" };
            queue.Formatter = new System.Messaging.XmlMessageFormatter(targetTypeNames);
            System.Messaging.MessageQueueTransaction trans = GetFromPropertyBag<System.Messaging.MessageQueueTransaction>(transaction.PropertyBag, Keys.Transaction); // transaction.PropertyBag[Keys.Transaction] as System.Messaging.MessageQueueTransaction;

            try
            {
                message = queue.Receive(new TimeSpan(0), trans);
            }
            catch (System.Messaging.MessageQueueException)
            {
                if (queue == null)
                    throw new Bss.ReliableMessaging.QueueEmptyException();
                else
                    throw new Bss.ReliableMessaging.QueueEmptyException(queue.Path);
            }

            return message.Body.ToString();
        }

        public Bss.ReliableMessaging.IReliableMessagingTransaction BeginReadTransaction(string queue)
        {
            System.Messaging.MessageQueue mq = new System.Messaging.MessageQueue(queue, System.Messaging.QueueAccessMode.Receive);

            if (!mq.Transactional)
            {
                string errorMessage = string.Format("Queue '{0}' does not support transactions", queue);
                LogEvent("Reliable Messaging Error", errorMessage, 2, System.Diagnostics.EventLogEntryType.Error);
                throw new System.NotSupportedException(errorMessage);
            }

            return new Transaction(mq);
        }

        public Bss.ReliableMessaging.IReliableMessagingTransaction BeginWriteTransaction(string queue)
        {
            System.Messaging.MessageQueue mq = new System.Messaging.MessageQueue(queue, System.Messaging.QueueAccessMode.Send);

            if (!mq.Transactional)
            {
                string errorMessage = string.Format("Queue '{0}' does not support transactions", queue);
                LogEvent("Reliable Messaging Error", errorMessage, 2, System.Diagnostics.EventLogEntryType.Error);
                throw new System.NotSupportedException(errorMessage);
            }

            return new Transaction(mq);
        }

        #endregion

        #region IDisposable Members

        public void Dispose()
        {
            _loggingProvider = null;
            GC.SuppressFinalize(this);
        }

        public long GetQueueDepth(string queue)
        {
            using (System.Messaging.MessageQueue q = new System.Messaging.MessageQueue(queue, System.Messaging.QueueAccessMode.PeekAndAdmin))
            {
                long count = 0;
                Cursor cursor = q.CreateCursor();

                Message m = PeekWithoutTimeout(q, cursor, PeekAction.Current);
                {
                    count = 1;
                    while ((m = PeekWithoutTimeout(q, cursor, PeekAction.Next)) != null)
                    {
                        count++;
                    }
                }
                return count;
            }
        }

        #endregion

        #region Private Helper Methods

        private void PutMessageOnQueue(System.Messaging.MessageQueue queue, System.Messaging.MessageQueueTransaction trans, string message)
        {
            if (queue == null)
            {
                string errorMessage = string.Format("Unable to enqueue message because the queue is unavailable");
                LogEvent("Queue Unavailable", errorMessage, 2, System.Diagnostics.EventLogEntryType.Error);
                throw new System.InvalidOperationException(errorMessage);
            }

            if (trans == null)
            {
                string errorMessage = string.Format("Unable to enqueue message because the transaction is unavailable");
                LogEvent("Transaction Unavailable", errorMessage, 2, System.Diagnostics.EventLogEntryType.Error);
                throw new System.InvalidOperationException(errorMessage);
            }

            queue.Send(message, trans);
        }

        protected Message PeekWithoutTimeout(MessageQueue q, Cursor cursor, PeekAction action)
        {
            Message ret = null;
            try
            {
                ret = q.Peek(new TimeSpan(1), cursor, action);
            }
            catch (MessageQueueException mqe)
            {
                if (!mqe.Message.ToLower().Contains("timeout"))
                {
                    throw;
                }
            }
            return ret;
        }

        private static T GetFromPropertyBag<T>(Dictionary<string, object> bag, string key)
        {
            T result = default(T);
            if ((bag != null) && bag.ContainsKey(key) && (bag[key] != null) && (bag[key] is T))
                result = (T)bag[key];
            return result;
        }

        private void LogEvent(string eventTitle, string eventMessage, int priority, System.Diagnostics.EventLogEntryType eventType)
        {
            _loggingProvider.Write(eventTitle, _eventCategory, eventMessage, priority, eventType);
        }

        #endregion

    }
}

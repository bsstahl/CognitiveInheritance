﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bss.ReliableMessaging.Msmq
{
    public class Transaction : Bss.ReliableMessaging.IReliableMessagingTransaction
    {
        Guid _id = Guid.NewGuid();
        Dictionary<string, object> _propertyBag = new Dictionary<string, object>();

        public Transaction(System.Messaging.MessageQueue queue)
        {
            _propertyBag.Add(Keys.Queue, queue);

            System.Messaging.MessageQueueTransaction trans = new System.Messaging.MessageQueueTransaction();
            trans.Begin();

            _propertyBag.Add(Keys.Transaction, trans);
        }

        private System.Messaging.MessageQueue Queue
        {
            get
            {
                System.Messaging.MessageQueue result = null;
                if ((_propertyBag != null) && (_propertyBag.ContainsKey(Keys.Queue))
                    && (_propertyBag[Keys.Queue] != null) && (_propertyBag[Keys.Queue] is System.Messaging.MessageQueue))
                    result = _propertyBag[Keys.Queue] as System.Messaging.MessageQueue;
                return result;
            }
        }

        private System.Messaging.MessageQueueTransaction MsmqTransaction
        {
            get
            {
                System.Messaging.MessageQueueTransaction result = null;
                if ((_propertyBag != null) && (_propertyBag.ContainsKey(Keys.Transaction))
                    && (_propertyBag[Keys.Transaction] != null) && (_propertyBag[Keys.Transaction] is System.Messaging.MessageQueueTransaction))
                    result = _propertyBag[Keys.Transaction] as System.Messaging.MessageQueueTransaction;
                return result;
            }
        }

        #region IReliableMessagingTransaction Members

        public Guid Id
        {
            get { return _id; }
        }

        public bool Active
        {
            get
            {
                System.Messaging.MessageQueueTransaction trans = this.MsmqTransaction;
                bool result = true;
                if (trans != null)
                    result = ((trans.Status == System.Messaging.MessageQueueTransactionStatus.Initialized) || (trans.Status == System.Messaging.MessageQueueTransactionStatus.Pending));
                return result;
            }
        }

        public Dictionary<string, object> PropertyBag
        {
            get { return _propertyBag; }
        }

        public void Commit()
        {
            this.MsmqTransaction.Commit();
            this.Queue.Close();
        }

        public void Rollback()
        {
            this.MsmqTransaction.Abort();
            this.Queue.Close();
        }

        #endregion

        #region IDisposable Members

        public void Dispose()
        {
            this.Queue.Dispose();
            _propertyBag[Keys.Queue] = null;

            this.MsmqTransaction.Dispose();
            _propertyBag[Keys.Transaction] = null;

            _propertyBag = null;

            GC.SuppressFinalize(this);
        }

        #endregion
    }
}

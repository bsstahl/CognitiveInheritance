﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bss.ReliableMessaging.Msmq
{
    public static class Keys
    {
        public static string Queue = "Queue";
        public static string Transaction = "Transaction";
    }
}

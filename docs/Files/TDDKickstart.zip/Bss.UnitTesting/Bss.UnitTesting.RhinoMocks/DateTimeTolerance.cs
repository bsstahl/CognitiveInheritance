﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bss.UnitTesting.RhinoMocks
{
    public static class DateTimeTolerance
    {
        public static TimeSpan Hour()
        {
            return TimeSpan.FromHours(1);
        }

        public static TimeSpan Minute()
        {
            return TimeSpan.FromMinutes(1);
        }

        public static TimeSpan Second()
        {
            return TimeSpan.FromSeconds(1);
        }
    }
}

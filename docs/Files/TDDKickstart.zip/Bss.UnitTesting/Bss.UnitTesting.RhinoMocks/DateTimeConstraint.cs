﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bss.UnitTesting.RhinoMocks
{
    public class DateTimeConstraint : Rhino.Mocks.Constraints.AbstractConstraint
    {
        DateTime _comparisonValue;
        TimeSpan _tolerance;
        string _message = string.Empty;

        public DateTimeConstraint(DateTime comparisonValue, TimeSpan tolerance)
        {
            _comparisonValue = comparisonValue;
            _tolerance = tolerance;
        }

        public override bool Eval(object obj)
        {
            bool result = false;

            if (obj.GetType() != typeof(System.DateTime))
                _message = "Object must be of type System.DateTime";
            else
            {
                DateTime objectUnderTest = Convert.ToDateTime(obj);
                TimeSpan duration = objectUnderTest.Subtract(_comparisonValue).Duration();
                int comparisonResult = duration.CompareTo(_tolerance);
                result = (comparisonResult <= 0);

                if (result)
                    _message = string.Format(System.Globalization.CultureInfo.CurrentCulture, "{0}", objectUnderTest);
                else
                    _message = string.Format(System.Globalization.CultureInfo.CurrentCulture, "'{0}' which is outside of the specified tolerance of {3} ms from '{1}' (actual = {2} ms).", objectUnderTest, _comparisonValue, duration.TotalMilliseconds, _tolerance.TotalMilliseconds);
            }

            return result;
        }

        public override string Message
        {
            get { return _message; }
        }
    }
}

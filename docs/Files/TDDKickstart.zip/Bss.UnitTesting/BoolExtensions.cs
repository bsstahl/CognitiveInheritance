﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bss.UnitTesting
{
    public static class BoolExtensions
    {
        static Random _rnd = new Random();

        public static bool GetRandom(this bool ignored)
        {
            double value = _rnd.NextDouble();
            double roundedValue = System.Math.Round(value);
            byte intResult = Convert.ToByte(roundedValue);
            if (intResult == 0)
                return false;
            else
                return true;
        }
    }
}

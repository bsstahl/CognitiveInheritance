﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bss.UnitTesting
{
    public static class ObjectExtensions
    {
        public static int ToInt32(this object value)
        {
            return Convert.ToInt32(value, System.Globalization.CultureInfo.CurrentCulture);
        }

        public static Int64 ToInt64(this object value)
        {
            return Convert.ToInt64(value, System.Globalization.CultureInfo.CurrentCulture);
        }

        public static Int64? ToNullableInt64(this object value)
        {
            Int64? result = null;
            if (value != null && value != DBNull.Value)
                result = value.ToInt64();
            return result;
        }

        public static DateTime ToDateTime(this object value)
        {
            return Convert.ToDateTime(value, System.Globalization.CultureInfo.CurrentCulture);
        }

        public static DateTime? ToNullableDateTime(this object value)
        {
            DateTime? result = null;
            if (value != null && value != DBNull.Value)
                result = value.ToDateTime();
            return result;
        }

    }
}

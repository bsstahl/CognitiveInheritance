﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bss.UnitTesting
{
    public static class StringExtensions
    {
        public static string GetRandom(this string value)
        {
            return value.GetRandom(8);
        }

        public static string GetRandom(this string value, int length)
        {
            if (length < 1)
                throw new System.ArgumentException("length must be a positive integer", "length");

            string fullString = System.Guid.NewGuid().ToString();
            while (fullString.Length < length)
            {
                fullString += System.Guid.NewGuid().ToString();
            }

            return fullString.Substring(0, length);
        }

        public static string GetRandomUSPhoneNumber(this string value)
        {
            return string.Format(System.Globalization.CultureInfo.InvariantCulture, "{0}-{1}-{2}", 999.GetRandom(111), 999.GetRandom(111), 9999.GetRandom(1111));
        }

        public static System.IO.Stream ToStream(this string value)
        {
            using (var buffer = new System.IO.MemoryStream())
            {
                var writer = new System.IO.StreamWriter(buffer);
                writer.Write(value);
                writer.Flush();
                return buffer;
            }
        }

    }
}

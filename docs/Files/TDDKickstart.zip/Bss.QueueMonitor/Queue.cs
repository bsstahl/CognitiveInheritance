﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bss.QueueMonitor
{
    public class Queue
    {
        Bss.Logging.ILoggingProvider _loggingProvider;
        Bss.ReliableMessaging.IReliableMessagingProvider _messagingProvider;
        Bss.QueueMonitor.Data.IQueueDepthRepository _repository;
        Bss.Timing.ITimingProvider _timingProvider;

        public string Name { get; private set; }

        public Queue(string name, Bss.Logging.ILoggingProvider loggingProvider,
            Bss.ReliableMessaging.IReliableMessagingProvider messagingProvider,
            Bss.QueueMonitor.Data.IQueueDepthRepository repository,
            Bss.Timing.ITimingProvider timingProvider)
        {
            this.Name = name;
            _loggingProvider = loggingProvider;
            _messagingProvider = messagingProvider;
            _repository = repository;
            _timingProvider = timingProvider;
        }

        public void Monitor(int executionCount, TimeSpan delayBetweenExecutions)
        {
            if (executionCount < 0)
            {
                _loggingProvider.LogError("Monitor", "ArgumentOutOfRange", "executionCount cannot be < 0 (currently {0}).", executionCount);
                throw new System.ArgumentOutOfRangeException("executionCount");
            }

            _loggingProvider.LogInformation("Monitor", "Begin Monitoring", "Begin monitoring of queue '{0}'", this.Name);

            int counter = 0;
            while (counter < executionCount)
            {
                if (counter > 0)
                    _timingProvider.Delay(delayBetweenExecutions);

                _loggingProvider.LogInformation("Monitor", "Begin Get", "Getting queue depth on '{0}'", this.Name);
                var depth = _messagingProvider.GetQueueDepth(this.Name);
                _loggingProvider.LogInformation("Monitor", "Begin Save", "Saving queue depth of {0} on '{1}'", depth, this.Name);
                _repository.SaveQueueDepth(this.Name, DateTime.UtcNow, depth);
                _loggingProvider.LogInformation("Monitor", "End Save", "Save completed for '{0}'", this.Name);

                counter++;
            }

            _loggingProvider.LogInformation("Monitor", "End Monitoring", "Finished monitoring queue '{0}'", this.Name);
        }
    }
}

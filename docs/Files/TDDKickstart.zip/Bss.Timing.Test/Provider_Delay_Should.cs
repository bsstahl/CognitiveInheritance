﻿using Bss.Timing;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Bss.UnitTesting;

namespace Bss.Timing.Test
{
    [TestClass()]
    public class Provider_Delay_Should
    {
        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion

        [TestMethod()]
        public void DelayShouldNotReturnMoreThan1MsFasterThanTheSpecifiedDelayTime()
        {
            long delayInMs = 100.GetRandom(10);
            int toleranceInMs = 1;
            long minDelayInMs = delayInMs - toleranceInMs;

            TimeSpan length = TimeSpan.FromMilliseconds(delayInMs);
            Provider target = new Provider();

            var stopwatch = new System.Diagnostics.Stopwatch();
            stopwatch.Start();
            target.Delay(length);
            stopwatch.Stop();

            long timeInDelay = stopwatch.ElapsedMilliseconds;

            TestContext.WriteLine("Expected: {0} ms", delayInMs);
            TestContext.WriteLine("Min Tolerance: {0} ms", minDelayInMs);
            TestContext.WriteLine("Actual: {0} ms", timeInDelay);

            Assert.IsTrue(timeInDelay >= minDelayInMs);
        }

        [TestMethod()]
        public void DelayShouldNotReturnMoreThan1MsSlowerThanTheSpecifiedDelayTime()
        {
            long delayInMs = 100.GetRandom(10);
            int toleranceInMs = 1;
            long maxDelayInMs = delayInMs + toleranceInMs;

            TimeSpan length = TimeSpan.FromMilliseconds(delayInMs);
            Provider target = new Provider();

            var stopwatch = new System.Diagnostics.Stopwatch();
            stopwatch.Start();
            target.Delay(length);
            stopwatch.Stop();

            long timeInDelay = stopwatch.ElapsedMilliseconds;

            TestContext.WriteLine("Expected: {0} ms", delayInMs);
            TestContext.WriteLine("Max Tolerance: {0} ms", maxDelayInMs);
            TestContext.WriteLine("Actual: {0} ms", timeInDelay);

            Assert.IsTrue(timeInDelay <= maxDelayInMs);
        }
    }
}

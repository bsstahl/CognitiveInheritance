﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bss.Timing
{
    public class Provider : ITimingProvider
    {
        public void Delay(TimeSpan length)
        {
            System.Threading.Thread.Sleep(length);
        }

        public void Delay(DateTime until)
        {
            throw new NotImplementedException();
        }
    }
}

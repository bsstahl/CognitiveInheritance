﻿using Bss.QueueMonitor;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Bss.Logging;
using Bss.ReliableMessaging;
using Bss.QueueMonitor.Data;
using Bss.Timing;
using Bss.UnitTesting;
using Bss.UnitTesting.RhinoMocks;

namespace Bss.QueueMonitor.Test
{
    [TestClass()]
    public class Queue_Monitor_Should
    {
        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion

        // Read all test names as if they were preceeded by the class name
        // i.e. Queue_Monitor_Should.NotCallSaveIfZeroExecutionsSpecified

        #region Validate Input Parameters

        [TestMethod(), ExpectedException(typeof(System.ArgumentOutOfRangeException))]
        public void ThrowAnArgumentOutOfRangeExceptionIfExecutionCountIsNegative()
        {
            // The expectation for this test is that a specific error is thrown.
            // The expectation is expressed in the "ExpectedException" decorator of the method meta-data above

            string name = string.Empty.GetRandom();
            int executionCount = (-1 * 50.GetRandom(1)); // <--- Random negative number of "executions"
            TimeSpan delayBetweenExecutions = TimeSpan.FromSeconds(0);

            var mocks = new Rhino.Mocks.MockRepository();

            ILoggingProvider loggingProvider = new Bss.Logging.TestContext.Provider(this.TestContext);
            IReliableMessagingProvider messagingProvider = mocks.Stub<IReliableMessagingProvider>();
            IQueueDepthRepository repository = mocks.Stub<IQueueDepthRepository>();
            ITimingProvider timingProvider = mocks.Stub<ITimingProvider>();

            mocks.ReplayAll();

            Queue target = new Queue(name, loggingProvider, messagingProvider, repository, timingProvider);
            target.Monitor(executionCount, delayBetweenExecutions);

            mocks.VerifyAll();
        }

        #endregion

        #region Validate Execution Counts

        [TestMethod()]
        public void NotCallSaveIfZeroExecutionsSpecified()
        {
            string name = string.Empty.GetRandom();
            int executionCount = 0; // <--- Execute 0 times
            TimeSpan delayBetweenExecutions = TimeSpan.FromSeconds(0);

            var mocks = new Rhino.Mocks.MockRepository();

            ILoggingProvider loggingProvider = new Bss.Logging.TestContext.Provider(this.TestContext);
            IReliableMessagingProvider messagingProvider = mocks.Stub<IReliableMessagingProvider>();

            // A DynamicMock is used here so future calls to other repository methods won't break this test
            IQueueDepthRepository repository = mocks.DynamicMock<IQueueDepthRepository>();
            
            ITimingProvider timingProvider = mocks.Stub<ITimingProvider>();

            repository.SaveQueueDepth(string.Empty, DateTime.MinValue, 0);
            Rhino.Mocks.LastCall.IgnoreArguments().Repeat.Never(); // <--- Expect exactly Zero executions

            mocks.ReplayAll();

            Queue target = new Queue(name, loggingProvider, messagingProvider, repository, timingProvider);
            target.Monitor(executionCount, delayBetweenExecutions);

            mocks.VerifyAll();
        }

        [TestMethod()]
        public void CallSaveOnceIfOneExecutionSpecified()
        {
            string name = string.Empty.GetRandom();
            int executionCount = 1; // <--- Execute one time
            TimeSpan delayBetweenExecutions = TimeSpan.FromSeconds(0);

            var mocks = new Rhino.Mocks.MockRepository();

            ILoggingProvider loggingProvider = new Bss.Logging.TestContext.Provider(this.TestContext);
            IReliableMessagingProvider messagingProvider = mocks.Stub<IReliableMessagingProvider>();

            // A StrictMock is used here so we can check for "EXACTLY 1" execution instead of "at least 1"
            // the risk of using a StrictMock rather than a DynamicMock is that the test is more brittle -- if
            // in the future, we add functionality and something else calls the repository, this test will break
            IQueueDepthRepository repository = mocks.StrictMock<IQueueDepthRepository>();

            ITimingProvider timingProvider = mocks.Stub<ITimingProvider>();

            repository.SaveQueueDepth(string.Empty, DateTime.MinValue, 0);
            Rhino.Mocks.LastCall.IgnoreArguments().Repeat.Once(); // <--- Expect one execution

            mocks.ReplayAll();

            Queue target = new Queue(name, loggingProvider, messagingProvider, repository, timingProvider);
            target.Monitor(executionCount, delayBetweenExecutions);

            mocks.VerifyAll();
        }

        [TestMethod()]
        public void CallSaveOnceForEachExecution()
        {
            string name = string.Empty.GetRandom();
            int executionCount = 50.GetRandom(2); // <--- Execute between 2 and 49 times
            TimeSpan delayBetweenExecutions = TimeSpan.FromSeconds(0);

            var mocks = new Rhino.Mocks.MockRepository();

            ILoggingProvider loggingProvider = new Bss.Logging.TestContext.Provider(this.TestContext);
            IReliableMessagingProvider messagingProvider = mocks.Stub<IReliableMessagingProvider>();

            // A StrictMock is used here so we can check for "EXACTLY N" executions instead of "at least N"
            // the risk of using a StrictMock rather than a DynamicMock is that the test is more brittle -- if
            // in the future, we add functionality and something else calls the repository, this test will break
            IQueueDepthRepository repository = mocks.StrictMock<IQueueDepthRepository>();

            ITimingProvider timingProvider = mocks.Stub<ITimingProvider>();

            repository.SaveQueueDepth(string.Empty, DateTime.MinValue, 0);
            Rhino.Mocks.LastCall.IgnoreArguments().Repeat.Times(executionCount);  // <--- Expect the requested number of executions

            mocks.ReplayAll();

            Queue target = new Queue(name, loggingProvider, messagingProvider, repository, timingProvider);
            target.Monitor(executionCount, delayBetweenExecutions);

            mocks.VerifyAll();
        }

        [TestMethod()]
        public void CallGetOnceForEachExecution()
        {
            string name = string.Empty.GetRandom();
            int executionCount = 50.GetRandom(2); // <--- Execute between 2 and 49 times
            TimeSpan delayBetweenExecutions = TimeSpan.FromSeconds(0);

            var mocks = new Rhino.Mocks.MockRepository();

            ILoggingProvider loggingProvider = new Bss.Logging.TestContext.Provider(this.TestContext);

            // A StrictMock is used here so we can check for "EXACTLY N" executions instead of "at least N"
            // the risk of using a StrictMock rather than a DynamicMock is that the test is more brittle -- if
            // in the future, we add functionality and something else calls the repository, this test will break
            IReliableMessagingProvider messagingProvider = mocks.StrictMock<IReliableMessagingProvider>();

            IQueueDepthRepository repository = mocks.Stub<IQueueDepthRepository>();
            ITimingProvider timingProvider = mocks.Stub<ITimingProvider>();

            Rhino.Mocks.Expect.Call(messagingProvider.GetQueueDepth(string.Empty)).IgnoreArguments().Return(0).Repeat.Times(executionCount);

            mocks.ReplayAll();

            Queue target = new Queue(name, loggingProvider, messagingProvider, repository, timingProvider);
            target.Monitor(executionCount, delayBetweenExecutions);

            mocks.VerifyAll();
        }

        [TestMethod()]
        public void NotCallDelayIfZeroExecutionsSpecified()
        {
            string name = string.Empty.GetRandom();
            int executionCount = 0;  // <--- Execute 0 times
            TimeSpan delayBetweenExecutions = TimeSpan.FromSeconds(0);

            var mocks = new Rhino.Mocks.MockRepository();

            ILoggingProvider loggingProvider = new Bss.Logging.TestContext.Provider(this.TestContext);
            IReliableMessagingProvider messagingProvider = mocks.Stub<IReliableMessagingProvider>();
            IQueueDepthRepository repository = mocks.Stub<IQueueDepthRepository>();
            ITimingProvider timingProvider = mocks.DynamicMock<ITimingProvider>();

            timingProvider.Delay(TimeSpan.FromSeconds(0));
            Rhino.Mocks.LastCall.IgnoreArguments().Repeat.Never(); // <--- Call delay exactly 0 times

            mocks.ReplayAll();

            Queue target = new Queue(name, loggingProvider, messagingProvider, repository, timingProvider);
            target.Monitor(executionCount, delayBetweenExecutions);

            mocks.VerifyAll();
        }

        [TestMethod()]
        public void CallDelayOnceForEachExecutionExceptTheFirst()
        {
            string name = string.Empty.GetRandom();
            int executionCount = 50.GetRandom(1); // <--- Execute between 1 and 49 times
            TimeSpan delayBetweenExecutions = TimeSpan.FromSeconds(0);

            var mocks = new Rhino.Mocks.MockRepository();

            ILoggingProvider loggingProvider = new Bss.Logging.TestContext.Provider(this.TestContext);
            IReliableMessagingProvider messagingProvider = mocks.Stub<IReliableMessagingProvider>();
            IQueueDepthRepository repository = mocks.Stub<IQueueDepthRepository>();

            // A StrictMock is used here so we can check for "EXACTLY N" executions instead of "at least N"
            // the risk of using a StrictMock rather than a DynamicMock is that the test is more brittle -- if
            // in the future, we add functionality and something else calls the repository, this test will break
            ITimingProvider timingProvider = mocks.StrictMock<ITimingProvider>();

            timingProvider.Delay(TimeSpan.FromSeconds(0));
            Rhino.Mocks.LastCall.IgnoreArguments().Repeat.Times(executionCount - 1);  // <--- Call Delay N-1 times

            mocks.ReplayAll();

            Queue target = new Queue(name, loggingProvider, messagingProvider, repository, timingProvider);
            target.Monitor(executionCount, delayBetweenExecutions);

            mocks.VerifyAll();
        }

        #endregion

        #region Validate Dependency Parameters

        [TestMethod()]
        public void CallGetWithTheProperQueueName()
        {
            string name = string.Empty.GetRandom(); // <--- Random queue name
            int executionCount = 1;
            TimeSpan delayBetweenExecutions = TimeSpan.FromSeconds(0);

            var mocks = new Rhino.Mocks.MockRepository();

            ILoggingProvider loggingProvider = new Bss.Logging.TestContext.Provider(this.TestContext);
            IReliableMessagingProvider messagingProvider = mocks.DynamicMock<IReliableMessagingProvider>(); // <--- Dynamic mock
            IQueueDepthRepository repository = mocks.Stub<IQueueDepthRepository>();
            ITimingProvider timingProvider = mocks.Stub<ITimingProvider>();

            Rhino.Mocks.Expect.Call(messagingProvider.GetQueueDepth(string.Empty)).IgnoreArguments().Return(0)
                .Constraints(Rhino.Mocks.Constraints.Text.Like(name))  // <--- Param 1 of the GetQueueDepth call should match the random queue name
                .Repeat.Once();

            mocks.ReplayAll();

            Queue target = new Queue(name, loggingProvider, messagingProvider, repository, timingProvider);
            target.Monitor(executionCount, delayBetweenExecutions);

            mocks.VerifyAll();
        }

        [TestMethod()]
        public void CallSaveWithTheProperQueueName()
        {
            string name = string.Empty.GetRandom(); // <--- Random queue name
            int executionCount = 1;
            TimeSpan delayBetweenExecutions = TimeSpan.FromSeconds(0);

            var mocks = new Rhino.Mocks.MockRepository();

            ILoggingProvider loggingProvider = new Bss.Logging.TestContext.Provider(this.TestContext);
            IReliableMessagingProvider messagingProvider = mocks.Stub<IReliableMessagingProvider>();
            IQueueDepthRepository repository = mocks.DynamicMock<IQueueDepthRepository>(); // <---  Dyanmic Mock
            ITimingProvider timingProvider = mocks.Stub<ITimingProvider>();

            repository.SaveQueueDepth(string.Empty, DateTime.MinValue, 0);
            Rhino.Mocks.LastCall.IgnoreArguments()
                .Constraints(
                    Rhino.Mocks.Constraints.Text.Like(name), // <--- Param 1 of the SaveQueueDepth call should match the random queue name
                    Rhino.Mocks.Constraints.Is.Anything(),
                    Rhino.Mocks.Constraints.Is.Anything())
                .Repeat.Once();

            mocks.ReplayAll();

            Queue target = new Queue(name, loggingProvider, messagingProvider, repository, timingProvider);
            target.Monitor(executionCount, delayBetweenExecutions);

            mocks.VerifyAll();
        }

        [TestMethod()]
        public void CallSaveWithTheProperQueryDateTime()
        {
            string name = string.Empty.GetRandom();
            int executionCount = 1;
            TimeSpan delayBetweenExecutions = TimeSpan.FromSeconds(0);

            var mocks = new Rhino.Mocks.MockRepository();

            ILoggingProvider loggingProvider = new Bss.Logging.TestContext.Provider(this.TestContext);
            IReliableMessagingProvider messagingProvider = mocks.Stub<IReliableMessagingProvider>();
            IQueueDepthRepository repository = mocks.DynamicMock<IQueueDepthRepository>(); // <---  Dynamic Mock
            ITimingProvider timingProvider = mocks.Stub<ITimingProvider>();

            repository.SaveQueueDepth(string.Empty, DateTime.MinValue, 0);
            Rhino.Mocks.LastCall.IgnoreArguments()
                .Constraints(
                    Rhino.Mocks.Constraints.Is.Anything(),
                    new DateTimeConstraint(DateTime.UtcNow, DateTimeTolerance.Second()), // <---  Param 2 of the SaveQueueDepth call should be within 1 sec of UtcNow
                    Rhino.Mocks.Constraints.Is.Anything())
                .Repeat.Once();

            mocks.ReplayAll();

            Queue target = new Queue(name, loggingProvider, messagingProvider, repository, timingProvider);
            target.Monitor(executionCount, delayBetweenExecutions);

            mocks.VerifyAll();
        }

        [TestMethod()]
        public void CallSaveWithTheQueueDepthFromTheGetCall()
        {
            string name = string.Empty.GetRandom();
            int executionCount = 1;
            Int64 result = Int64.MaxValue.GetRandom(); // <---  Random queue depth
            TimeSpan delayBetweenExecutions = TimeSpan.FromSeconds(0);

            var mocks = new Rhino.Mocks.MockRepository();

            ILoggingProvider loggingProvider = new Bss.Logging.TestContext.Provider(this.TestContext);
            IReliableMessagingProvider messagingProvider = mocks.Stub<IReliableMessagingProvider>();
            IQueueDepthRepository repository = mocks.DynamicMock<IQueueDepthRepository>(); // <---  Dyanamic mock
            ITimingProvider timingProvider = mocks.Stub<ITimingProvider>();

            Rhino.Mocks.Expect.Call(messagingProvider.GetQueueDepth(string.Empty)).IgnoreArguments().Return(result).Repeat.Once(); // <---  Return the random queue depth when GetQueueDepth is called

            repository.SaveQueueDepth(string.Empty, DateTime.MinValue, 0);
            Rhino.Mocks.LastCall.IgnoreArguments()
                .Constraints(
                    Rhino.Mocks.Constraints.Is.Anything(),
                    Rhino.Mocks.Constraints.Is.Anything(),
                    Rhino.Mocks.Constraints.Is.Equal(result)) // <---  Param 3 of the SaveQueueDepth call should be the random queue depth from the GetQueueDepth call
                .Repeat.Once();

            mocks.ReplayAll();

            Queue target = new Queue(name, loggingProvider, messagingProvider, repository, timingProvider);
            target.Monitor(executionCount, delayBetweenExecutions);

            mocks.VerifyAll();
        }

        [TestMethod()]
        public void CallDelayWithTheProperTimespan()
        {
            string name = string.Empty.GetRandom();
            int executionCount = 2;
            TimeSpan delayBetweenExecutions = TimeSpan.FromMilliseconds(Int32.MaxValue.GetRandom()); // <---  Random TimeSpan (probably very long)

            var mocks = new Rhino.Mocks.MockRepository();

            ILoggingProvider loggingProvider = new Bss.Logging.TestContext.Provider(this.TestContext);
            IReliableMessagingProvider messagingProvider = mocks.Stub<IReliableMessagingProvider>();
            IQueueDepthRepository repository = mocks.Stub<IQueueDepthRepository>();
            ITimingProvider timingProvider = mocks.DynamicMock<ITimingProvider>(); // <---  Dynamic mock

            timingProvider.Delay(delayBetweenExecutions); // <---  The Random TimeSpan from above
            Rhino.Mocks.LastCall.Repeat.Once(); // <---  Since we don't "IgnoreArguments", the argument here must match what we specified in the call

            mocks.ReplayAll();

            Queue target = new Queue(name, loggingProvider, messagingProvider, repository, timingProvider);
            target.Monitor(executionCount, delayBetweenExecutions);

            mocks.VerifyAll();
        }


        #endregion

    }
}

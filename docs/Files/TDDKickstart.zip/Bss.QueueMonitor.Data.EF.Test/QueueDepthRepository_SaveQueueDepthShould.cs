﻿using Bss.QueueMonitor.Data.EF;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Bss.UnitTesting;

namespace Bss.QueueMonitor.Data.EF.Test
{
    [TestClass()]
    public class QueueDepthRepository_SaveQueueDepthShould
    {
        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        // Only 1 test is needed to validate that the correct data is being saved, even though there are 3 parameters,
        // because the 1st two parameters make-up the primary key of the record and therefore cannot be accessed independantly.
        // For example, we can't check if the DateTime is stored correctly by using the QueueName and QueueDepth because 
        // we could get multiple records returned for that combination.
        [TestMethod()]
        public void StoreTheQueueDepthInTheDatabase()
        {
            string sourceQueueName = string.Empty.GetRandom();
            DateTime queryDateTime = DateTime.UtcNow.To10MSPrecision();

            long depth = Int32.MaxValue.GetRandom() + 10000;

            IQueueDepthRepository target = new QueueDepthRepository();

            try
            {
                TestContext.WriteLine("Saving depth {2} for queue '{0}' at '{1:MM/dd/yyyy HH:mm:ss.FFF}'.", sourceQueueName, queryDateTime, depth);
                target.SaveQueueDepth(sourceQueueName, queryDateTime, depth);

                // Verify the data was saved correctly using the test helper method
                long actual = Database.GetDepth(sourceQueueName, queryDateTime);
                Assert.AreEqual(depth, actual);
            }
            finally
            {
                Database.DeleteRecord(sourceQueueName, queryDateTime);
            }
        }
    }
}

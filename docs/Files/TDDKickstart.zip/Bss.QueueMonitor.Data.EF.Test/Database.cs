﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;
using System.Data;

namespace Bss.QueueMonitor.Data.EF.Test
{

    // All of these helper methods use ADO.Net to do their work. This is a somewhat primitive methodology, but it is good for unit testing
    // because we don't want to test our work using the same methods that we use to create the production version. i.e., we don't want to create
    // an Entity Framework library for our unit tests, or worse, use the production EF library to validate itself. Creating a new EF library for
    // testing the production one might lead to the same mistakes being made in both places, rendering the tests ineffective.

    internal static class Database
    {
        internal static Int64 GetDepth(string queueName, DateTime queryDateTimeUtc)
        {
            string sql = string.Format("select DepthValue from DepthEntries where SourceQueueName='{0}' and Convert(varchar,QueryDateTimeUtc,20) = Convert(varchar,Convert(DateTime, '{1:MM/dd/yyyy HH:mm:ss.FF}'),20)", queueName, queryDateTimeUtc);
            return ExecuteLong(sql);
        }

        internal static void DeleteRecord(string queueName, DateTime queryDateTimeUtc)
        {
            string sql = string.Format("delete from DepthEntries where SourceQueueName='{0}' and Convert(varchar,QueryDateTimeUtc,20) = Convert(varchar,Convert(DateTime, '{1:MM/dd/yyyy HH:mm:ss.FF}'),20)", queueName, queryDateTimeUtc);
            ExecuteNonQuery(sql);
        }

        internal static void ExecuteNonQuery(string sql)
        {
            string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["QueueDepth"].ConnectionString;
            var db = new System.Data.SqlClient.SqlConnection(connectionString);
            var cmd = new System.Data.SqlClient.SqlCommand(sql, db);
            db.Open();
            cmd.ExecuteNonQuery();
            db.Close();
        }

        internal static long ExecuteLong(string sql)
        {
            var dt = ExecuteDataTable(sql);
            if (dt.Rows.Count < 1)
                throw new System.NullReferenceException("No rows returned");
            else if (dt.Rows.Count > 1)
                throw new System.InvalidOperationException("Multiple rows returned");
            else
                return Convert.ToInt64(dt.Rows[0][0]);
        }

        internal static DataTable ExecuteDataTable(string sql)
        {
            var ds = ExecuteDataSet(sql);
            if (ds.Tables.Count < 1)
                throw new System.NullReferenceException("No table returned");
            else if (ds.Tables.Count > 1)
                throw new System.InvalidOperationException("Multiple tables returned");
            else
                return ds.Tables[0];
        }

        internal static DataSet ExecuteDataSet(string sql)
        {
            string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["QueueDepth"].ConnectionString;
            var db = new System.Data.SqlClient.SqlConnection(connectionString);
            var cmd = new System.Data.SqlClient.SqlCommand(sql, db);
            var da = new System.Data.SqlClient.SqlDataAdapter(cmd);

            var ds = new System.Data.DataSet();
            da.Fill(ds);

            db.Close();

            return ds;
        }

    }
}

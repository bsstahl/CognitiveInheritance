
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, and Azure
-- --------------------------------------------------
-- Date Created: 01/25/2012 11:44:25
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [TDDDemo];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------


-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[DepthEntries]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DepthEntries];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'DepthEntries'
CREATE TABLE [dbo].[DepthEntries] (
    [SourceQueueName] nvarchar(400)  NOT NULL,
    [QueryDateTimeUtc] datetime  NOT NULL,
    [DepthValue] bigint  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [SourceQueueName], [QueryDateTimeUtc] in table 'DepthEntries'
ALTER TABLE [dbo].[DepthEntries]
ADD CONSTRAINT [PK_DepthEntries]
    PRIMARY KEY CLUSTERED ([SourceQueueName], [QueryDateTimeUtc] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------
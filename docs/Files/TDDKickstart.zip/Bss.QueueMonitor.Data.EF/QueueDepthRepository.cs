﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;

namespace Bss.QueueMonitor.Data.EF
{
    public class QueueDepthRepository: Data.IQueueDepthRepository
    {
        public void SaveQueueDepth(string sourceQueueName, DateTime queryDateTime, long queueDepth)
        {
            using (var context = new QueueDepthModelContainer1())
            {
                DepthEntry entry = context.DepthEntries.CreateObject();
                context.DepthEntries.AddObject(entry);

                entry.SourceQueueName = sourceQueueName;
                entry.QueryDateTimeUtc = queryDateTime;
                entry.DepthValue = queueDepth;

                context.SaveChanges();
            }
        }
    }
}

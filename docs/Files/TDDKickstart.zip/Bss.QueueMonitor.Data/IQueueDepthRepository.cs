﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bss.QueueMonitor.Data
{
    public interface IQueueDepthRepository
    {
        void SaveQueueDepth(string sourceQueueName, DateTime queryDateTime, Int64 depth);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bss.Logging.TestContext
{
    public class Provider : LoggingProviderBase
    {
        Microsoft.VisualStudio.TestTools.UnitTesting.TestContext _context;

        public Provider(Microsoft.VisualStudio.TestTools.UnitTesting.TestContext context)
        {
            _context = context;
        }

        #region ILoggingProvider Members

        public override void Write(string category, string title, string message, int severity, System.Diagnostics.EventLogEntryType entryType)
        {
            _context.WriteLine("Logger: {0} ({1}/{3}) - {2}\r\n", title, category, message, severity);
        }

        #endregion
    }
}

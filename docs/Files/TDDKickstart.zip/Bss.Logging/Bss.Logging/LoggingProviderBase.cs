﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bss.Logging
{
    public abstract class LoggingProviderBase:ILoggingProvider
    {
        #region ILoggingProvider Members

        public abstract void Write(string category, string title, string message, int severity, System.Diagnostics.EventLogEntryType entryType);

        public void LogCrash(string category, string title, string messageFormat, params object[] messageParameters)
        {
            LogCrash(category, title, string.Format(System.Globalization.CultureInfo.CurrentCulture, messageFormat, messageParameters));
        }

        public void LogCrash(string category, string title, string message)
        {
            Write(category, title, message, 0, System.Diagnostics.EventLogEntryType.Error);
        }

        public void LogError(string category, string title, string messageFormat, params object[] messageParameters)
        {
            LogError(category, title, string.Format(System.Globalization.CultureInfo.CurrentCulture, messageFormat, messageParameters));
        }

        public void LogError(string category, string title, string message)
        {
            Write(category, title, message, 2, System.Diagnostics.EventLogEntryType.Error);
        }

        public void LogInformation(string category, string title, string messageFormat, params object[] messageParameters)
        {
            LogInformation(category, title, string.Format(System.Globalization.CultureInfo.CurrentCulture, messageFormat, messageParameters));
        }

        public void LogInformation(string category, string title, string message)
        {
            Write(category, title, message, 5, System.Diagnostics.EventLogEntryType.Information);
        }

        public void LogWarning(string category, string title, string messageFormat, params object[] messageParameters)
        {
            LogWarning(category, title, string.Format(System.Globalization.CultureInfo.CurrentCulture, messageFormat, messageParameters));
        }

        public void LogWarning(string category, string title, string message)
        {
            Write(category, title, message, 3, System.Diagnostics.EventLogEntryType.Warning);
        }

        #endregion
    }
}

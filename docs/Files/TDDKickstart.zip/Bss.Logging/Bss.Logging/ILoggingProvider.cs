﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bss.Logging
{
    public interface ILoggingProvider
    {
        void Write(string category, string title, string message, int severity, System.Diagnostics.EventLogEntryType entryType);

        void LogInformation(string category, string title, string message);
        void LogWarning(string category, string title, string message);
        void LogError(string category, string title, string message);
        void LogCrash(string category, string title, string message);

        void LogInformation(string category, string title, string messageFormat, params object[] messageParameters);
        void LogWarning(string category, string title, string messageFormat, params object[] messageParameters);
        void LogError(string category, string title, string messageFormat, params object[] messageParameters);
        void LogCrash(string category, string title, string messageFormat, params object[] messageParameters);
    }
}

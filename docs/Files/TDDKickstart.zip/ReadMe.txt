Some notes on these files
-------------------------

* Be sure to read the Unit Testing/TDD FAQ at http://www.cognitiveinheritance.com/page/Unit-Testing-and-TDD-FAQ.aspx for 
answers to some of the questions you may have on this library.

* I only bring tests into a solution if I am modifying that project in that solution.  For all of the pre-existing dependencies 
in this solution (i.e. Logging, ReliableMessaging, etc), no mods have been made, so there are no tests for them in this solution.  
The Timing module is new for this project, so the solution contains unit tests for it.


